#!/bin/sh

/daisypi/all_readings.sh
sleep 25
/daisypi/all_readings.sh
