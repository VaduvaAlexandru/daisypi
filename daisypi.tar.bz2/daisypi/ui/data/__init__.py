'''Model the entities.'''

import flask.ext.sqlalchemy

DB = flask.ext.sqlalchemy.SQLAlchemy()
